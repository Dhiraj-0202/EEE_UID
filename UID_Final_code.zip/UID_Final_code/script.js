let espIP = "";

function setIP() {
  const ip = document.getElementById("ipInput").value.trim();
  espIP = `http://${ip}`;
  alert("Connected to " + espIP);
}

function sendCommand(cmd) {
  if (!espIP) {
    alert("Enter ESP8266 IP first!");
    return;
  }
  fetch(`${espIP}/${cmd}`)
    .then(res => res.text())
    .then(data => console.log(data))
    .catch(err => console.error(err));
}
